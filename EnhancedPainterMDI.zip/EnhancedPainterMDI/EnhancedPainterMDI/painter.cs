﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EnhancedPainterMDI
{
    public partial class painter : Form
    {
        bool shouldPaint = false;
        SolidBrush brush = new SolidBrush(Color.Red);
        int sizeValue1 = 0;
        int sizeValue2 = 0;

        public painter()
        {
            InitializeComponent();
        }

        private void painter_MouseDown(object sender, MouseEventArgs e)
        {
            shouldPaint = true;
        }

        private void painter_MouseUp(object sender, MouseEventArgs e)
        {
            shouldPaint = false;
        }

        private void red_radioButton_Click(object sender, EventArgs e)
        {
            brush.Color = Color.Red;
        }

        private void blue_radioButton_Click(object sender, EventArgs e)
        {
            brush.Color = Color.Blue;
        }

        private void green_radioButton_Click(object sender, EventArgs e)
        {
            brush.Color = Color.Green;
        }

        private void black_radioButton_Click(object sender, EventArgs e)
        {
            brush.Color = Color.Black;
        }

        private void small_radioButton_Click(object sender, EventArgs e)
        {
            sizeValue1 = 4;
            sizeValue2 = 4;
        }

        private void med_radioButton_Click(object sender, EventArgs e)
        {
            sizeValue1 = 8;
            sizeValue2 = 8;
        }

        private void large_radioButton_Click(object sender, EventArgs e)
        {
            sizeValue1 = 12;
            sizeValue2 = 12;
        }

        private void painter_MouseMove(object sender, MouseEventArgs e)
        {
            if(shouldPaint)
            {
                using (Graphics graphics = CreateGraphics())
                {
                    graphics.FillEllipse(brush, e.X, e.Y, sizeValue1, sizeValue2);
                }
            }
        }
    }
}
