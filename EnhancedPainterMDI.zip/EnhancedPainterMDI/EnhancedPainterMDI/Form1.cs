﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EnhancedPainterMDI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        painter p2;
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(p2==null)
            {
                p2 = new painter();
                p2.MdiParent = this;
                p2.FormClosed += P2_FormClosed;
                p2.Show();

            }
            else
            {
                p2.Activate();
            }
        }

        private void P2_FormClosed(object sender, FormClosedEventArgs e)
        {
            p2 = null;
            //throw new NotImplementedException();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
