﻿namespace EnhancedPainterMDI
{
    partial class painter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.color_groupBox = new System.Windows.Forms.GroupBox();
            this.black_radioButton = new System.Windows.Forms.RadioButton();
            this.green_radioButton = new System.Windows.Forms.RadioButton();
            this.blue_radioButton = new System.Windows.Forms.RadioButton();
            this.red_radioButton = new System.Windows.Forms.RadioButton();
            this.size_groupBox = new System.Windows.Forms.GroupBox();
            this.large_radioButton = new System.Windows.Forms.RadioButton();
            this.med_radioButton = new System.Windows.Forms.RadioButton();
            this.small_radioButton = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.color_groupBox.SuspendLayout();
            this.size_groupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // color_groupBox
            // 
            this.color_groupBox.Controls.Add(this.black_radioButton);
            this.color_groupBox.Controls.Add(this.green_radioButton);
            this.color_groupBox.Controls.Add(this.blue_radioButton);
            this.color_groupBox.Controls.Add(this.red_radioButton);
            this.color_groupBox.Location = new System.Drawing.Point(21, 19);
            this.color_groupBox.Name = "color_groupBox";
            this.color_groupBox.Size = new System.Drawing.Size(72, 115);
            this.color_groupBox.TabIndex = 0;
            this.color_groupBox.TabStop = false;
            this.color_groupBox.Text = "Color";
            // 
            // black_radioButton
            // 
            this.black_radioButton.AutoSize = true;
            this.black_radioButton.Location = new System.Drawing.Point(7, 91);
            this.black_radioButton.Name = "black_radioButton";
            this.black_radioButton.Size = new System.Drawing.Size(52, 17);
            this.black_radioButton.TabIndex = 3;
            this.black_radioButton.TabStop = true;
            this.black_radioButton.Text = "Black";
            this.black_radioButton.UseVisualStyleBackColor = true;
            this.black_radioButton.Click += new System.EventHandler(this.black_radioButton_Click);
            // 
            // green_radioButton
            // 
            this.green_radioButton.AutoSize = true;
            this.green_radioButton.Location = new System.Drawing.Point(7, 68);
            this.green_radioButton.Name = "green_radioButton";
            this.green_radioButton.Size = new System.Drawing.Size(54, 17);
            this.green_radioButton.TabIndex = 2;
            this.green_radioButton.TabStop = true;
            this.green_radioButton.Text = "Green";
            this.green_radioButton.UseVisualStyleBackColor = true;
            this.green_radioButton.Click += new System.EventHandler(this.green_radioButton_Click);
            // 
            // blue_radioButton
            // 
            this.blue_radioButton.AutoSize = true;
            this.blue_radioButton.Location = new System.Drawing.Point(7, 45);
            this.blue_radioButton.Name = "blue_radioButton";
            this.blue_radioButton.Size = new System.Drawing.Size(46, 17);
            this.blue_radioButton.TabIndex = 1;
            this.blue_radioButton.TabStop = true;
            this.blue_radioButton.Text = "Blue";
            this.blue_radioButton.UseVisualStyleBackColor = true;
            this.blue_radioButton.Click += new System.EventHandler(this.blue_radioButton_Click);
            // 
            // red_radioButton
            // 
            this.red_radioButton.AutoSize = true;
            this.red_radioButton.Location = new System.Drawing.Point(7, 22);
            this.red_radioButton.Name = "red_radioButton";
            this.red_radioButton.Size = new System.Drawing.Size(45, 17);
            this.red_radioButton.TabIndex = 0;
            this.red_radioButton.TabStop = true;
            this.red_radioButton.Text = "Red";
            this.red_radioButton.UseVisualStyleBackColor = true;
            this.red_radioButton.Click += new System.EventHandler(this.red_radioButton_Click);
            // 
            // size_groupBox
            // 
            this.size_groupBox.Controls.Add(this.large_radioButton);
            this.size_groupBox.Controls.Add(this.med_radioButton);
            this.size_groupBox.Controls.Add(this.small_radioButton);
            this.size_groupBox.Location = new System.Drawing.Point(21, 141);
            this.size_groupBox.Name = "size_groupBox";
            this.size_groupBox.Size = new System.Drawing.Size(72, 100);
            this.size_groupBox.TabIndex = 1;
            this.size_groupBox.TabStop = false;
            this.size_groupBox.Text = "Size";
            // 
            // large_radioButton
            // 
            this.large_radioButton.AutoSize = true;
            this.large_radioButton.Location = new System.Drawing.Point(7, 68);
            this.large_radioButton.Name = "large_radioButton";
            this.large_radioButton.Size = new System.Drawing.Size(52, 17);
            this.large_radioButton.TabIndex = 2;
            this.large_radioButton.TabStop = true;
            this.large_radioButton.Text = "Large";
            this.large_radioButton.UseVisualStyleBackColor = true;
            this.large_radioButton.Click += new System.EventHandler(this.large_radioButton_Click);
            // 
            // med_radioButton
            // 
            this.med_radioButton.AutoSize = true;
            this.med_radioButton.Location = new System.Drawing.Point(7, 44);
            this.med_radioButton.Name = "med_radioButton";
            this.med_radioButton.Size = new System.Drawing.Size(62, 17);
            this.med_radioButton.TabIndex = 1;
            this.med_radioButton.TabStop = true;
            this.med_radioButton.Text = "Medium";
            this.med_radioButton.UseVisualStyleBackColor = true;
            this.med_radioButton.Click += new System.EventHandler(this.med_radioButton_Click);
            // 
            // small_radioButton
            // 
            this.small_radioButton.AutoSize = true;
            this.small_radioButton.Location = new System.Drawing.Point(7, 20);
            this.small_radioButton.Name = "small_radioButton";
            this.small_radioButton.Size = new System.Drawing.Size(50, 17);
            this.small_radioButton.TabIndex = 0;
            this.small_radioButton.TabStop = true;
            this.small_radioButton.Text = "Small";
            this.small_radioButton.UseVisualStyleBackColor = true;
            this.small_radioButton.Click += new System.EventHandler(this.small_radioButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "David Spalla";
            // 
            // painter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1252, 640);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.size_groupBox);
            this.Controls.Add(this.color_groupBox);
            this.Name = "painter";
            this.Text = "Painter";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.painter_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.painter_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.painter_MouseUp);
            this.color_groupBox.ResumeLayout(false);
            this.color_groupBox.PerformLayout();
            this.size_groupBox.ResumeLayout(false);
            this.size_groupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox color_groupBox;
        private System.Windows.Forms.RadioButton black_radioButton;
        private System.Windows.Forms.RadioButton green_radioButton;
        private System.Windows.Forms.RadioButton blue_radioButton;
        private System.Windows.Forms.RadioButton red_radioButton;
        private System.Windows.Forms.GroupBox size_groupBox;
        private System.Windows.Forms.RadioButton small_radioButton;
        private System.Windows.Forms.RadioButton large_radioButton;
        private System.Windows.Forms.RadioButton med_radioButton;
        private System.Windows.Forms.Label label1;
    }
}