﻿using System;
using System.Linq;

namespace hugeInteger
{
    class MainClass
    {
        public int[] firstDigit = new int[40];
        public int[] secondDigit = new int[40];
        Boolean error;

        public int firstNumber = 0;
        public int secondNumber = 0;

        public static void Main(string[] args)
        {
            Console.Write("Enter first number: ");
            int firstNumber = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nEnter second number: ");
            int secondNumber = Convert.ToInt32(Console.ReadLine());
            Input(firstNumber, secondNumber);
        }

        private void Input(int bigNumber, int bigNumber2)
        {
            firstDigit = bigNumber.ToString().Select(o => Convert.ToInt32(o)).ToArray();
            secondDigit = bigNumber2.ToString().Select(o => Convert.ToInt32(o)).ToArray();
        }

        private bool isZero(int input)
        {
            bool temp = false;
            if (input == 0)
            {
                temp = true;
            }
            return temp;

        }

        private String toString(int[] input)
        {
            return input.ToString();
        }

        private int Add (int first, int second)
        {
            return first + second;
        }


        private bool isEqualTo(int first, int second)
        {
            bool temp = false;
            if(first == second)
            {
                temp = true;
            }
            return temp;
        }

        private bool isGreaterThan(int first, int second)
        {
            bool temp = false;
            if(first > second)
            {
                temp = true;
            }
            return temp;
        }

        private bool isGreaterThanorEqualTo(int first, int second)
        {
            bool temp = false;
            if(first >= second)
            {
                temp = true;
            }
            return temp;
        }



       
    }
}
