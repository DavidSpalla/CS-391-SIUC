﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace spalla_assignment3
{
    class MainClass
    {
        
        public static void Main(string[] args)
        {
            Random random = new Random();
            List<char> characters = new List<char>();

            char letter = ' ';

            for (int i = 0; i < 30; i++)
            {
                letter = (char)random.Next(65, 91);
                characters.Add(letter);
            }

            var up = from letters in characters
                        orderby letters ascending
                        select letters;

            foreach (var e in up)
            {
                Console.Write(e + " ");
            }
            Console.WriteLine();


            var down = from letters in characters
                       orderby letters descending
                       select letters;

            foreach (var e in down)
            {
                Console.Write(e + " ");
            }
            Console.WriteLine();


            var upNoDup = (from letters in characters
                           orderby letters ascending
                           select letters).Distinct();

            foreach (var e in upNoDup)
            {
                Console.Write(e + " ");
            }
            Console.WriteLine();


        }
    }
}
