﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace spalla_assignment5
{
    public partial class Form1 : Form
    {
        public String wordStorage = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonKeyDown(object sender, KeyEventArgs e)
        {
            space_Button.BackColor = Color.White;
            delete_Button.BackColor = Color.White;
            q_Button.BackColor = Color.White;
            w_button.BackColor = Color.White;
            e_Button.BackColor = Color.White;
            r_Button.BackColor = Color.White;
            t_Button.BackColor = Color.White;
            y_Button.BackColor = Color.White;
            u_Button.BackColor = Color.White;
            i_Button.BackColor = Color.White;
            o_Button.BackColor = Color.White;
            p_Button.BackColor = Color.White;
            a_Button.BackColor = Color.White;
            s_Button.BackColor = Color.White;
            d_Button.BackColor = Color.White;
            f_Button.BackColor = Color.White;
            g_Button.BackColor = Color.White;
            h_Button.BackColor = Color.White;
            j_Button.BackColor = Color.White;
            k_Button.BackColor = Color.White;
            l_Button.BackColor = Color.White;
            z_Button.BackColor = Color.White;
            x_Button.BackColor = Color.White;
            c_Button.BackColor = Color.White;
            v_Button.BackColor = Color.White;
            b_Button.BackColor = Color.White;
            n_Button.BackColor = Color.White;
            m_Button.BackColor = Color.White;



            if (e.KeyValue == (char)Keys.Space)
            {
                space_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + " ";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.Q)
            {
                q_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "Q";
                outputBox.AppendText(wordStorage);
                wordStorage = "";

            }
            else if (e.KeyValue == (char)Keys.W)
            {
                w_button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "W";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.E)
            {
                e_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "E";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.R)
            {
                r_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "R";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.T)
            {
                t_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "T";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.Y)
            {
                y_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "Y";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.U)
            {
                u_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "U";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.I)
            {
                i_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "I";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.O)
            {
                o_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "O";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.P)
            {
                p_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "P";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.A)
            {
                a_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "A";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.S)
            {
                s_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "S";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.D)
            {
                d_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "D";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.F)
            {
                f_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "F";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.G)
            {
                g_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "G";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.H)
            {
                h_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "H";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.J)
            {
                j_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "J";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.K)
            {
                k_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "K";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.L)
            {
                l_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "L";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.Z)
            {
                z_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "Z";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.X)
            {
                x_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "X";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.C)
            {
                c_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "C";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.V)
            {
                v_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "V";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.B)
            {
                b_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "B";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.N)
            {
                n_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "N";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }
            else if (e.KeyValue == (char)Keys.M)
            {
                m_Button.BackColor = Color.DarkOrange;
                wordStorage = wordStorage + "M";
                outputBox.AppendText(wordStorage);
                wordStorage = "";
            }

            else if (e.KeyValue == (char)Keys.Delete)
            {
                delete_Button.BackColor = Color.DarkOrange;
                outputBox.Text = String.Empty;
            }

        }

        
    }
}
