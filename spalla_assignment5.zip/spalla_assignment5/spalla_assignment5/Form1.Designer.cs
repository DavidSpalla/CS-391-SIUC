﻿namespace spalla_assignment5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.keysContainer = new System.Windows.Forms.GroupBox();
            this.space_Button = new System.Windows.Forms.Button();
            this.m_Button = new System.Windows.Forms.Button();
            this.n_Button = new System.Windows.Forms.Button();
            this.b_Button = new System.Windows.Forms.Button();
            this.v_Button = new System.Windows.Forms.Button();
            this.c_Button = new System.Windows.Forms.Button();
            this.x_Button = new System.Windows.Forms.Button();
            this.z_Button = new System.Windows.Forms.Button();
            this.l_Button = new System.Windows.Forms.Button();
            this.k_Button = new System.Windows.Forms.Button();
            this.j_Button = new System.Windows.Forms.Button();
            this.h_Button = new System.Windows.Forms.Button();
            this.g_Button = new System.Windows.Forms.Button();
            this.f_Button = new System.Windows.Forms.Button();
            this.d_Button = new System.Windows.Forms.Button();
            this.s_Button = new System.Windows.Forms.Button();
            this.a_Button = new System.Windows.Forms.Button();
            this.p_Button = new System.Windows.Forms.Button();
            this.o_Button = new System.Windows.Forms.Button();
            this.i_Button = new System.Windows.Forms.Button();
            this.u_Button = new System.Windows.Forms.Button();
            this.y_Button = new System.Windows.Forms.Button();
            this.t_Button = new System.Windows.Forms.Button();
            this.r_Button = new System.Windows.Forms.Button();
            this.e_Button = new System.Windows.Forms.Button();
            this.w_button = new System.Windows.Forms.Button();
            this.q_Button = new System.Windows.Forms.Button();
            this.outputBox = new System.Windows.Forms.TextBox();
            this.delete_Button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.keysContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // keysContainer
            // 
            this.keysContainer.Controls.Add(this.label2);
            this.keysContainer.Controls.Add(this.label1);
            this.keysContainer.Controls.Add(this.delete_Button);
            this.keysContainer.Controls.Add(this.space_Button);
            this.keysContainer.Controls.Add(this.m_Button);
            this.keysContainer.Controls.Add(this.n_Button);
            this.keysContainer.Controls.Add(this.b_Button);
            this.keysContainer.Controls.Add(this.v_Button);
            this.keysContainer.Controls.Add(this.c_Button);
            this.keysContainer.Controls.Add(this.x_Button);
            this.keysContainer.Controls.Add(this.z_Button);
            this.keysContainer.Controls.Add(this.l_Button);
            this.keysContainer.Controls.Add(this.k_Button);
            this.keysContainer.Controls.Add(this.j_Button);
            this.keysContainer.Controls.Add(this.h_Button);
            this.keysContainer.Controls.Add(this.g_Button);
            this.keysContainer.Controls.Add(this.f_Button);
            this.keysContainer.Controls.Add(this.d_Button);
            this.keysContainer.Controls.Add(this.s_Button);
            this.keysContainer.Controls.Add(this.a_Button);
            this.keysContainer.Controls.Add(this.p_Button);
            this.keysContainer.Controls.Add(this.o_Button);
            this.keysContainer.Controls.Add(this.i_Button);
            this.keysContainer.Controls.Add(this.u_Button);
            this.keysContainer.Controls.Add(this.y_Button);
            this.keysContainer.Controls.Add(this.t_Button);
            this.keysContainer.Controls.Add(this.r_Button);
            this.keysContainer.Controls.Add(this.e_Button);
            this.keysContainer.Controls.Add(this.w_button);
            this.keysContainer.Controls.Add(this.q_Button);
            this.keysContainer.Location = new System.Drawing.Point(12, 12);
            this.keysContainer.Name = "keysContainer";
            this.keysContainer.Size = new System.Drawing.Size(426, 154);
            this.keysContainer.TabIndex = 0;
            this.keysContainer.TabStop = false;
            this.keysContainer.Text = "Keys";
            // 
            // space_Button
            // 
            this.space_Button.BackColor = System.Drawing.Color.White;
            this.space_Button.Location = new System.Drawing.Point(101, 118);
            this.space_Button.Name = "space_Button";
            this.space_Button.Size = new System.Drawing.Size(168, 23);
            this.space_Button.TabIndex = 26;
            this.space_Button.Text = "--";
            this.space_Button.UseVisualStyleBackColor = false;
            // 
            // m_Button
            // 
            this.m_Button.BackColor = System.Drawing.Color.White;
            this.m_Button.Location = new System.Drawing.Point(231, 89);
            this.m_Button.Name = "m_Button";
            this.m_Button.Size = new System.Drawing.Size(23, 23);
            this.m_Button.TabIndex = 25;
            this.m_Button.Text = "M";
            this.m_Button.UseVisualStyleBackColor = false;
            // 
            // n_Button
            // 
            this.n_Button.BackColor = System.Drawing.Color.White;
            this.n_Button.Location = new System.Drawing.Point(202, 89);
            this.n_Button.Name = "n_Button";
            this.n_Button.Size = new System.Drawing.Size(23, 23);
            this.n_Button.TabIndex = 24;
            this.n_Button.Text = "N";
            this.n_Button.UseVisualStyleBackColor = false;
            // 
            // b_Button
            // 
            this.b_Button.BackColor = System.Drawing.Color.White;
            this.b_Button.Location = new System.Drawing.Point(173, 89);
            this.b_Button.Name = "b_Button";
            this.b_Button.Size = new System.Drawing.Size(23, 23);
            this.b_Button.TabIndex = 23;
            this.b_Button.Text = "B";
            this.b_Button.UseVisualStyleBackColor = false;
            // 
            // v_Button
            // 
            this.v_Button.BackColor = System.Drawing.Color.White;
            this.v_Button.Location = new System.Drawing.Point(144, 89);
            this.v_Button.Name = "v_Button";
            this.v_Button.Size = new System.Drawing.Size(23, 23);
            this.v_Button.TabIndex = 22;
            this.v_Button.Text = "V";
            this.v_Button.UseVisualStyleBackColor = false;
            // 
            // c_Button
            // 
            this.c_Button.BackColor = System.Drawing.Color.White;
            this.c_Button.Location = new System.Drawing.Point(115, 89);
            this.c_Button.Name = "c_Button";
            this.c_Button.Size = new System.Drawing.Size(23, 23);
            this.c_Button.TabIndex = 21;
            this.c_Button.Text = "C";
            this.c_Button.UseVisualStyleBackColor = false;
            // 
            // x_Button
            // 
            this.x_Button.BackColor = System.Drawing.Color.White;
            this.x_Button.Location = new System.Drawing.Point(86, 89);
            this.x_Button.Name = "x_Button";
            this.x_Button.Size = new System.Drawing.Size(23, 23);
            this.x_Button.TabIndex = 20;
            this.x_Button.Text = "X";
            this.x_Button.UseVisualStyleBackColor = false;
            // 
            // z_Button
            // 
            this.z_Button.BackColor = System.Drawing.Color.White;
            this.z_Button.Location = new System.Drawing.Point(57, 89);
            this.z_Button.Name = "z_Button";
            this.z_Button.Size = new System.Drawing.Size(23, 23);
            this.z_Button.TabIndex = 19;
            this.z_Button.Text = "Z";
            this.z_Button.UseVisualStyleBackColor = false;
            // 
            // l_Button
            // 
            this.l_Button.BackColor = System.Drawing.Color.White;
            this.l_Button.Location = new System.Drawing.Point(275, 60);
            this.l_Button.Name = "l_Button";
            this.l_Button.Size = new System.Drawing.Size(23, 23);
            this.l_Button.TabIndex = 18;
            this.l_Button.Text = "L";
            this.l_Button.UseVisualStyleBackColor = false;
            // 
            // k_Button
            // 
            this.k_Button.BackColor = System.Drawing.Color.White;
            this.k_Button.Location = new System.Drawing.Point(246, 60);
            this.k_Button.Name = "k_Button";
            this.k_Button.Size = new System.Drawing.Size(23, 23);
            this.k_Button.TabIndex = 17;
            this.k_Button.Text = "K";
            this.k_Button.UseVisualStyleBackColor = false;
            // 
            // j_Button
            // 
            this.j_Button.BackColor = System.Drawing.Color.Silver;
            this.j_Button.Location = new System.Drawing.Point(217, 60);
            this.j_Button.Name = "j_Button";
            this.j_Button.Size = new System.Drawing.Size(23, 23);
            this.j_Button.TabIndex = 16;
            this.j_Button.Text = "J";
            this.j_Button.UseVisualStyleBackColor = false;
            // 
            // h_Button
            // 
            this.h_Button.BackColor = System.Drawing.Color.White;
            this.h_Button.Location = new System.Drawing.Point(188, 60);
            this.h_Button.Name = "h_Button";
            this.h_Button.Size = new System.Drawing.Size(23, 23);
            this.h_Button.TabIndex = 15;
            this.h_Button.Text = "H";
            this.h_Button.UseVisualStyleBackColor = false;
            // 
            // g_Button
            // 
            this.g_Button.BackColor = System.Drawing.Color.White;
            this.g_Button.Location = new System.Drawing.Point(159, 60);
            this.g_Button.Name = "g_Button";
            this.g_Button.Size = new System.Drawing.Size(23, 23);
            this.g_Button.TabIndex = 14;
            this.g_Button.Text = "G";
            this.g_Button.UseVisualStyleBackColor = false;
            // 
            // f_Button
            // 
            this.f_Button.BackColor = System.Drawing.Color.Silver;
            this.f_Button.Location = new System.Drawing.Point(130, 60);
            this.f_Button.Name = "f_Button";
            this.f_Button.Size = new System.Drawing.Size(23, 23);
            this.f_Button.TabIndex = 13;
            this.f_Button.Text = "F";
            this.f_Button.UseVisualStyleBackColor = false;
            // 
            // d_Button
            // 
            this.d_Button.BackColor = System.Drawing.Color.White;
            this.d_Button.Location = new System.Drawing.Point(101, 60);
            this.d_Button.Name = "d_Button";
            this.d_Button.Size = new System.Drawing.Size(23, 23);
            this.d_Button.TabIndex = 12;
            this.d_Button.Text = "D";
            this.d_Button.UseVisualStyleBackColor = false;
            // 
            // s_Button
            // 
            this.s_Button.BackColor = System.Drawing.Color.White;
            this.s_Button.Location = new System.Drawing.Point(72, 60);
            this.s_Button.Name = "s_Button";
            this.s_Button.Size = new System.Drawing.Size(23, 23);
            this.s_Button.TabIndex = 11;
            this.s_Button.Text = "S";
            this.s_Button.UseVisualStyleBackColor = false;
            // 
            // a_Button
            // 
            this.a_Button.BackColor = System.Drawing.Color.White;
            this.a_Button.Location = new System.Drawing.Point(43, 60);
            this.a_Button.Name = "a_Button";
            this.a_Button.Size = new System.Drawing.Size(23, 23);
            this.a_Button.TabIndex = 10;
            this.a_Button.Text = "A";
            this.a_Button.UseVisualStyleBackColor = false;
            // 
            // p_Button
            // 
            this.p_Button.BackColor = System.Drawing.Color.White;
            this.p_Button.Location = new System.Drawing.Point(289, 31);
            this.p_Button.Name = "p_Button";
            this.p_Button.Size = new System.Drawing.Size(23, 23);
            this.p_Button.TabIndex = 9;
            this.p_Button.Text = "P";
            this.p_Button.UseVisualStyleBackColor = false;
            // 
            // o_Button
            // 
            this.o_Button.BackColor = System.Drawing.Color.White;
            this.o_Button.Location = new System.Drawing.Point(260, 31);
            this.o_Button.Name = "o_Button";
            this.o_Button.Size = new System.Drawing.Size(23, 23);
            this.o_Button.TabIndex = 8;
            this.o_Button.Text = "O";
            this.o_Button.UseVisualStyleBackColor = false;
            // 
            // i_Button
            // 
            this.i_Button.BackColor = System.Drawing.Color.White;
            this.i_Button.Location = new System.Drawing.Point(231, 31);
            this.i_Button.Name = "i_Button";
            this.i_Button.Size = new System.Drawing.Size(23, 23);
            this.i_Button.TabIndex = 7;
            this.i_Button.Text = "I";
            this.i_Button.UseVisualStyleBackColor = false;
            // 
            // u_Button
            // 
            this.u_Button.BackColor = System.Drawing.Color.White;
            this.u_Button.Location = new System.Drawing.Point(202, 31);
            this.u_Button.Name = "u_Button";
            this.u_Button.Size = new System.Drawing.Size(23, 23);
            this.u_Button.TabIndex = 6;
            this.u_Button.Text = "U";
            this.u_Button.UseVisualStyleBackColor = false;
            // 
            // y_Button
            // 
            this.y_Button.BackColor = System.Drawing.Color.White;
            this.y_Button.Location = new System.Drawing.Point(173, 31);
            this.y_Button.Name = "y_Button";
            this.y_Button.Size = new System.Drawing.Size(23, 23);
            this.y_Button.TabIndex = 5;
            this.y_Button.Text = "Y";
            this.y_Button.UseVisualStyleBackColor = false;
            // 
            // t_Button
            // 
            this.t_Button.BackColor = System.Drawing.Color.White;
            this.t_Button.Location = new System.Drawing.Point(144, 31);
            this.t_Button.Name = "t_Button";
            this.t_Button.Size = new System.Drawing.Size(23, 23);
            this.t_Button.TabIndex = 4;
            this.t_Button.Text = "T";
            this.t_Button.UseVisualStyleBackColor = false;
            // 
            // r_Button
            // 
            this.r_Button.BackColor = System.Drawing.Color.White;
            this.r_Button.Location = new System.Drawing.Point(115, 31);
            this.r_Button.Name = "r_Button";
            this.r_Button.Size = new System.Drawing.Size(23, 23);
            this.r_Button.TabIndex = 3;
            this.r_Button.Text = "R";
            this.r_Button.UseVisualStyleBackColor = false;
            // 
            // e_Button
            // 
            this.e_Button.BackColor = System.Drawing.Color.White;
            this.e_Button.Location = new System.Drawing.Point(86, 31);
            this.e_Button.Name = "e_Button";
            this.e_Button.Size = new System.Drawing.Size(23, 23);
            this.e_Button.TabIndex = 2;
            this.e_Button.Text = "E";
            this.e_Button.UseVisualStyleBackColor = false;
            // 
            // w_button
            // 
            this.w_button.BackColor = System.Drawing.Color.White;
            this.w_button.Location = new System.Drawing.Point(57, 31);
            this.w_button.Name = "w_button";
            this.w_button.Size = new System.Drawing.Size(23, 23);
            this.w_button.TabIndex = 1;
            this.w_button.Text = "W";
            this.w_button.UseVisualStyleBackColor = false;
            // 
            // q_Button
            // 
            this.q_Button.BackColor = System.Drawing.Color.White;
            this.q_Button.Location = new System.Drawing.Point(28, 31);
            this.q_Button.Name = "q_Button";
            this.q_Button.Size = new System.Drawing.Size(23, 23);
            this.q_Button.TabIndex = 0;
            this.q_Button.Text = "Q";
            this.q_Button.UseVisualStyleBackColor = false;
            this.q_Button.KeyDown += new System.Windows.Forms.KeyEventHandler(this.buttonKeyDown);
            // 
            // outputBox
            // 
            this.outputBox.Location = new System.Drawing.Point(12, 172);
            this.outputBox.Multiline = true;
            this.outputBox.Name = "outputBox";
            this.outputBox.ReadOnly = true;
            this.outputBox.Size = new System.Drawing.Size(426, 49);
            this.outputBox.TabIndex = 1;
            // 
            // delete_Button
            // 
            this.delete_Button.BackColor = System.Drawing.Color.White;
            this.delete_Button.Enabled = false;
            this.delete_Button.Location = new System.Drawing.Point(335, 31);
            this.delete_Button.Name = "delete_Button";
            this.delete_Button.Size = new System.Drawing.Size(51, 23);
            this.delete_Button.TabIndex = 27;
            this.delete_Button.Text = "Delete";
            this.delete_Button.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(336, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 26);
            this.label1.TabIndex = 28;
            this.label1.Text = "Delete removes \r\nall characters.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(0, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 29;
            this.label2.Text = "David Spalla";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(452, 233);
            this.Controls.Add(this.outputBox);
            this.Controls.Add(this.keysContainer);
            this.Name = "Form1";
            this.Text = "TypingTutor - David Spalla";
            this.keysContainer.ResumeLayout(false);
            this.keysContainer.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox keysContainer;
        private System.Windows.Forms.TextBox outputBox;
        private System.Windows.Forms.Button t_Button;
        private System.Windows.Forms.Button r_Button;
        private System.Windows.Forms.Button e_Button;
        private System.Windows.Forms.Button w_button;
        private System.Windows.Forms.Button q_Button;
        private System.Windows.Forms.Button m_Button;
        private System.Windows.Forms.Button n_Button;
        private System.Windows.Forms.Button b_Button;
        private System.Windows.Forms.Button v_Button;
        private System.Windows.Forms.Button c_Button;
        private System.Windows.Forms.Button x_Button;
        private System.Windows.Forms.Button z_Button;
        private System.Windows.Forms.Button l_Button;
        private System.Windows.Forms.Button k_Button;
        private System.Windows.Forms.Button j_Button;
        private System.Windows.Forms.Button h_Button;
        private System.Windows.Forms.Button g_Button;
        private System.Windows.Forms.Button f_Button;
        private System.Windows.Forms.Button d_Button;
        private System.Windows.Forms.Button s_Button;
        private System.Windows.Forms.Button a_Button;
        private System.Windows.Forms.Button p_Button;
        private System.Windows.Forms.Button o_Button;
        private System.Windows.Forms.Button i_Button;
        private System.Windows.Forms.Button u_Button;
        private System.Windows.Forms.Button y_Button;
        private System.Windows.Forms.Button space_Button;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button delete_Button;
        private System.Windows.Forms.Label label2;
    }
}

